
class var2
{
	
	public static void main(String args[])
	{
		int a=10;
		double b=a;
		System.out.println("A IS:"+a);
		System.out.println("B IS:"+b);

		double c=10.2;
		int d=(int) c;
		System.out.println("C IS:"+c);
		System.out.println("D IS:"+d);
		
	}
}