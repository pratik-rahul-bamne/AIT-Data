enum Language
{
	C,ANDROID,JAVA,PYTHON
}
class enum1
{
	public static void main(String args[])
	{
		Language l=Language.PYTHON;
		System.out.println(l);
		
	}
}