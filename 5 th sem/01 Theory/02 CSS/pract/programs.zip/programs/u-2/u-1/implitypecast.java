class implitypecast
{
	public static void main(String args[])
	{
		int x=10;	//4 bytes
		double y=x;    // 8 bytes (Implicit Conversion)
		
		System.out.println(x);
		System.out.println(y);
		
	}
}