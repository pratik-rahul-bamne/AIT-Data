class s3
{
	public static void main(String args[])
	{
		String s1="Hello";
		
		String s2=new String("Hello");
		
		boolean b=s1.equals(s2); //Try using if-else statement

		System.out.println(b);
	}
}
		