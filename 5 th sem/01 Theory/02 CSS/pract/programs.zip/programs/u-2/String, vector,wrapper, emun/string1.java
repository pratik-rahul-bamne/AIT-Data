import java.util.*;
class string1
{
	public static void main(String args[])
	{
		String name=new String();
		String address=new String();
		Scanner s=new Scanner(System.in);

		System.out.println("ENTER NAME:");
		name=s.nextLine();

		System.out.println("ENTER ADDRESS:");
		address=s.nextLine();

		System.out.println("NAME IS:"+name);
		System.out.println("ADDRESS IS:"+address);
		
		
	}
}