import java.applet.*;
import java.awt.event.*;
import java.awt.*;
/*<applet code="button1" height=300 width=300>
</applet>*/
public class button1 extends Applet implements ActionListener
{
	TextField t1=new TextField(10);
	TextField t2=new TextField(10);
	TextField t3=new TextField(10);
	Label l1=new L