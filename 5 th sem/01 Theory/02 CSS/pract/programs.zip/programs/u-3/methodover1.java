class methodover1
{	
	void add()
	{
		int a=10,b=20,c;
		c=a+b;
		System.out.println(c);
	}
	void add(int x, int y)
	{
		int c;
		c=x+y;
		System.out.println(c);
	}
	void add(int x, double y)
	{
		double c;
		c=x+y;
		System.out.println(c);
	}
	public static void main(String args[])
	{
		methodover1 m=new methodover1();
		m.add();
		m.add(5,5);
		m.add(12,52.32);
	}
}	
	