class s1
{
	public static void main(String args[])
	{
		String s1="Hello";
		System.out.println(s1);
		String s2="Hello";
		System.out.println(s2);
		s1=s1.concat("World");
		System.out.println(s1);
	}
}
		