import java.util.*;
class scan1
{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("ENTER NO:");
		int n=s.nextInt();
		if(n>0)
			System.out.println("POSITIVE NO");
		else 
			System.out.println("NEGATIVE NO");	
		
	}
}