import java.util.*;
class arr7
{
	public static void main(String args[])
	{
		int a[]={1,2,3,4,5};
		int b[]={1,2,3,4,5};
		
		if(Arrays.equals(a,b))
		{
			System.out.println("EQUAL");
		}
		else
		{
			System.out.println("NOT EQUAL");
		}
						
	}
}