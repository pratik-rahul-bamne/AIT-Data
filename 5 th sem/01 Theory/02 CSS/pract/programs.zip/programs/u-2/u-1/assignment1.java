
class assignment1
{
	
	public static void main(String args[])
	{		
		int a=10;	//Simple assignment
		a+=10;		// compound assignment a=a+10
		System.out.println(a);
		
	}
} 	