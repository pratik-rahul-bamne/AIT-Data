class const1
{
	public static void main(String args[])
	{
		int x=10;
		final int K=20;
		System.out.println(x);
		System.out.println(K);
		x=30;
		//K=40;
		System.out.println(x);
		System.out.println(K);
	}
}