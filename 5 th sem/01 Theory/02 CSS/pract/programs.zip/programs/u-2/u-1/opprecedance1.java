
class opprecedance1
{
	
	public static void main(String args[])
	{	
		int a=2*3/2	
		System.out.println(a);
		
		
	}
} 	