import java.applet.*;
import java.awt.*;
public class applet1 extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("HELLO CLASS",100,100);
	}
}