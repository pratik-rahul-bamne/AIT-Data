
class mathfun1
{
	
	public static void main(String args[])
	{		
		System.out.println(Math.max(5,2));
		System.out.println(Math.min(5,2));
		System.out.println(Math.sqrt(4));
		System.out.println(Math.pow(4,2));
		System.out.println(Math.round(10.2));
		System.out.println(Math.abs(-2.3));
		System.out.println(Math.exp(2));
		
	}
} 	