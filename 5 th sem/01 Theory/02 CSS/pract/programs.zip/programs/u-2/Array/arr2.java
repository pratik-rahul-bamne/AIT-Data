class arr2
{
	public static void main(String args[])
	{
		int a[]={10,20,30,40,60};
		for(int i=0;i<5;i++)
		{
			System.out.println(a[i]);
		}
	}
}