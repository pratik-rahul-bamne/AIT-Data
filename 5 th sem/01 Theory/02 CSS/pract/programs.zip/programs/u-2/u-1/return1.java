
class return1
{
	int add()
	{
		int a=10,b=20;
		return(a+b);
	}
	
	public static void main(String args[])
	{
		return1 ob=new return1();
		int x=ob.add();	
			
		System.out.println(x);
		
		
	}
} 	