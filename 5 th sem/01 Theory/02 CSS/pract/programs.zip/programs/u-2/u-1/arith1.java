
class arith1
{
	
	public static void main(String args[])
	{
		int a=21;
		int b=10;

		System.out.println("ADDITION IS:"+(a+b));
		System.out.println("SUBREACTION IS:"+(a-b));
		System.out.println("MULTIPLICATION IS:"+(a*b));
		System.out.println("DIVISION:"+(a/b));	
		System.out.println("MOD IS:"+(a%b));	

		
		
	}
}