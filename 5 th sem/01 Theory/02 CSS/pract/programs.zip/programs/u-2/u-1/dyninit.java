class dyninit
{
	public static void main(String args[])
	{
		double sqrt=Math.sqrt(16);
		System.out.println("SQUARE ROOT OF 16 IS:"+sqrt);
		
		
	}
}